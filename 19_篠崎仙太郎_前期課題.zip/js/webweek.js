'use strict'

const back = document.querySelector('.wrapper');


// gsap.to(back,{
//   scrollTrigger: {
//     trigger: back,
//     start: 'top top',
//     end: () => `+=${back.clientWidth}`,
//     scrub: true,
//     pin: true,
//     antipatePin: 1,
//     invalidateOnRefresh: true,
//     markers: true,
//   },
// })